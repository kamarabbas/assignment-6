//
//  Model.swift
//  CoredataApp
//
//  Created by KAMAR ABBAS SAIYAD on 10/04/23.
//

import Foundation
