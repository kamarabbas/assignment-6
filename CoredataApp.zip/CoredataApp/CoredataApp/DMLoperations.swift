//
//  DMLoperations.swift
//  CoredataApp
//
//  Created by KAMAR ABBAS SAIYAD on 10/04/23.
//

import UIKit
import CoreData

class DMLoperations: NSObject {
    
    let context=(UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    func savedata(data:[String:Any])
    {
        let insertStudinfo=NSEntityDescription.insertNewObject(forEntityName: "Studinfo", into: context) as! Studinfo
        insertStudinfo.name=data["name"] as? String
        insertStudinfo.sub=data["sub"] as? String
        insertStudinfo.city=data["city"] as? String
        insertStudinfo.mobile=((data["mobile"] as? Int64)!)
    
    }

}
