//
//  ViewController.swift
//  CoredataApp
//
//  Created by KAMAR ABBAS SAIYAD on 10/04/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var txt_name: UITextField!
    @IBOutlet weak var txt_subject: UITextField!
    @IBOutlet weak var txt_city: UITextField!
    @IBOutlet weak var txt_mobile: UITextField!
    
    
    var dml=DMLoperations()
    let context=(UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    func SaveStudinfo()
    {
        let stdata=["name":txt_name.text!,
                    "sub":txt_subject.text!,
                    "city":txt_city.text!,
                    "mobile":Int64(txt_mobile.text!) as Any]
        dml.savedata(data: stdata)
        do
        {
            try context.save()
            let alert=UIAlertController(title:"Success", message: "Your record has been inserted!", preferredStyle: .alert)
            let ok=UIAlertAction(title:"ok", style: .default, handler: nil)
            let more=UIAlertAction(title: "more", style: .destructive, handler: nil)
            alert.addAction(ok)
            alert.addAction(more)
            present(alert, animated: true, completion: nil)
        }
        catch
        {
            let alert=UIAlertController(title:"Error", message: "something went wrong", preferredStyle: .alert)
            let ok=UIAlertAction(title:"ok", style: .default, handler: nil)
            alert.addAction(ok)
            present(alert, animated: true, completion: nil)
        }
        
    }
    
    @IBAction func btn_save(_ sender: Any)
    {
        SaveStudinfo()
    }
    
}

